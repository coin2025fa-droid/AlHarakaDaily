# الحركة اليومية – إبراهيم (Android)

هذا مشروع Android WebView يضم نسخة HTML التي أرسلها المستخدم ويستخدم نفس إعدادات Supabase الموجودة فيها.

## بناء APK مجاناً عبر GitHub Actions
1. أنشئ مستودعاً جديداً في GitHub.
2. ارفع جميع ملفات هذا المشروع إلى المستودع (بما فيها مجلد `.github`).
3. افتح تبويب Actions وفعّل workflows إذا طلب GitHub ذلك.
4. اختر **Build Android APK** ثم **Run workflow**.
5. بعد نجاح البناء، افتح تشغيل workflow ثم نزّل artifact باسم `AlHarakaDaily-debug-apk`.
6. فك ضغط الملف الناتج وستجد `app-debug.apk`.

## ملاحظات
- هذا ملف APK تجريبي موقّع بمفتاح debug، مناسب للتثبيت والاختبار وليس للنشر التجاري في المتجر.
- يحتاج الإنترنت لأن Supabase ومكتبة Supabase JS يتم تحميلهما عبر الإنترنت.
- لا تغيّر SUPABASE_URL أو SUPABASE_KEY في `app/src/main/assets/index.html`.
- يجب اختبار تسجيل الدخول، صلاحيات RLS، الحفظ والمزامنة على الهاتف قبل الاعتماد عليه.
